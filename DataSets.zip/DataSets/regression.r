data("airquality")

attach(airquality)
names(airquality)
smp_size = floor(0.75*nrow(airquality))
smp_size

set.seed(123)
train_index = sample(seq_len(nrow(airquality)),size = smp_size)
train_index

#train data n test data

traindata = airquality[train_index,]
traindata

testdata = airquality[-train_index,]
testdata

#model making
lmMod = lm(Month~Temp,data = traindata)
lmMod
#predict function
distpred = predict(lmMod,testdata)
distpred

#train mse n test mse (mean squared predicted error)
train_mse = mean((traindata$Ozone - predict.lm(lmMod, traindata)) ^ 2,na.rm = TRUE)
train_mse

test_mse = mean((testdata$Ozone - predict.lm(lmMod, testdata)) ^ 2,na.rm = TRUE)
test_mse
#accuracy
actual_pred = data.frame(cbind(actuals=testdata$Temp,predicteds = distpred))
actual_pred

#correlation
correl = cor(actual_pred)
correl

#subset selection method
#install.packages("ISLR")

#graph airquality
plot(airquality$Ozone ~ airquality$Solar.R)

#linear regression using mean square method
#mean
mean.Ozone = mean(airquality$Ozone,na.rm = TRUE)
mean.Ozone

model1 = lm(airquality$Ozone ~ airquality$Solar.R)
abline(model1,col="red")

#different linear values
plot(model1)

summary(model1)

#plotting graph
scatter.smooth(x=airquality$Temp,y=airquality$Month,main="temp vs Month",col="red")


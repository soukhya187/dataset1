import java.math.BigInteger;

import java.util.Random;

import java.util.Scanner;


public class RSA
{
	
private static BigInteger p,q,N,phi,e,d;

	private int bitlen = 1024;

	private Random r;
	
	
public RSA()
{
		
r = new Random();
p = BigInteger.probablePrime(bitlen, r);
		
q = BigInteger.probablePrime(bitlen, r);
	
	
		N = p.multiply(q);

		phi = p.subtract(BigInteger.ONE).multiply(q.subtract(BigInteger.ONE));

		e = BigInteger.probablePrime(bitlen / 2, r);
		
	
	
while(phi.gcd(e).compareTo(BigInteger.ONE) > 0 && e.compareTo(phi) < 0)
{
			
e.add(BigInteger.ONE);
		
}

		
d = e.modInverse(phi);

}



	
	
private static String bytetostring(byte[] encrypted)
{
		
String toret = "";
		
for(byte b : encrypted)
{
		
	toret += Byte.toString(b);

		}
		
return toret;

}


	

	public static byte[] encrypt(byte[] msg)
{
		
byte[] estring;
	
	estring = (new BigInteger(msg)).modPow(e, N).toByteArray();
	
	return estring;

	}
	



	
public static byte[] decrypt(byte[] msg)
{
		
byte[] dstring;
	
	dstring = (new BigInteger(msg)).modPow(d, N).toByteArray();
	
	return dstring;

	}
	



	
public static void main(String[] args)
 {
		
RSA rsa = new RSA();
	
	Scanner in = new Scanner(System.in);

		
		
System.out.println("enter string to encrypt");
	
	String input = in.nextLine();
		

		System.out.println("\nencrypting...."+input);
	
	System.out.println("\n string in bytes ....."+bytetostring(input.getBytes()));
	
	
		byte[] encr = RSA.encrypt(input.getBytes());
	
	System.out.println("\nencrypted string is..." + new String(encr));
		

		byte[] decr = RSA.decrypt(encr);
		
System.out.println("\ndecrypted string is..."+ new String(decr));
		

		
	}
}
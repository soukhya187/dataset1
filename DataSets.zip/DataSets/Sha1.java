import java.io.*;

import java.util.*;

import java.security.*;


public class Sha1
{
		
static String sha1(String ip)throws NoSuchAlgorithmException
{

			
MessageDigest md = MessageDigest.getInstance("SHA1");
	
byte[] result     =     md.digest(ip.getBytes());

StringBuffer sb = new StringBuffer();
		
	for(int i=0;i<result.length;i++)
	{
		
                    sb.append(Integer.toString((result[i]&0xff) + 0x100,16).substring(1));

	}
	
	return sb.toString();

}



public static void main(String[] args)throws NoSuchAlgorithmException
{
	
Scanner scanner = new Scanner(System.in);
	

System.out.println("Enter string =");

String input = scanner.nextLine();
	
	
System.out.println("\nInput String is::"+input+"\nMessage Digest using sha1::"+sha1(input));

}


}
